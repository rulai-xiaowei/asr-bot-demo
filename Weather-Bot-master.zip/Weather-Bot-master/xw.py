query = input()
