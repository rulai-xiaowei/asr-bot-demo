# encoding: utf-8

from translate import Translator
C2E= Translator(from_lang="chinese",to_lang="english")
E2C= Translator(from_lang="english",to_lang="chinese")

translation = C2E.translate("成都")
t2= E2C.translate("The forecast in Chengdu 2020-12-04 is light rain.<br>High of 50 and low around 44.")
print(translation)
print(t2)
                  
