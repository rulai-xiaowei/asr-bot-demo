import win32com.client as client
 
def record(filename, text):

    fileStream = client.Dispatch("SAPI.SpFileStream")
    spVoice = client.Dispatch("SAPI.SpVoice")

    fileStream.Open(filename, 3, False)
    spVoice.AudioOutputStream = fileStream
    spVoice.Speak(text)
    fileStream.Close()


