import time
import argparse
import requests
import os
import sys
import collections
import speech
import win32com.client
import TTSfile
import client

from translate import Translator
import fanyi
import record

if __name__ == "__main__":

    
    while True:
        query = input()
        
        if query == "exit" :
            print("exit")
            break
        
        speech.say(query)

        #通过MIC来录音
        #print("开始录音...")
        #record.record_audio("voice.wav",4)

        #通过TTS产生声音
        TTSfile.record("voice.wav",query)
       
        answer = client.asr()
        print(answer)
        if answer =='' :
            print("未能识别")
            continue 
        

        resp=fanyi.translate(answer)
        print(resp)
        speech.say(resp)

