import socket
import os


def asr():

    #print("连接语音服务器")
    #os.system("scp voice.wav  xiaowei@192.168.1.251:kaldi-trunk/egs/thchs30/online_demo/online-data/audio/")
    os.system("scp voice.wav  xiaowei@192.168.1.251:kaldi-trunk/egs/librispeech/online_demo/online-data/audio/")
    print("开始识别......")
    ip_port = ('192.168.1.251',9000)
    BUFSIZE = 1024
    udp_server_client = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)


    msg = "start"
    udp_server_client.sendto(msg.encode('utf-8'),ip_port)
    back_msg,addr = udp_server_client.recvfrom(BUFSIZE)

    answer = back_msg.decode('utf-8')
    #print(answer)
    return answer



if __name__ == "__main__":
    asr()
